#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from tkinter import *
from tkinter.messagebox import showinfo

class MyGui(Frame):
    def __init__(self, parent=None):
        Frame.__init__(self, parent)
        button = Button(self, text='press', command=self.reply, activebackground = 'red')
        button.pack()
    def reply(self):
        showinfo(title='popup', message='Button pressed!')        
        
## Begin your code

## End your code

   


# In[ ]:




